<?php
class Infusionsoft_Campaign extends Infusionsoft_Generated_Campaign{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

