<?php
class Infusionsoft_ContactGroupAssign extends Infusionsoft_Generated_ContactGroupAssign{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

