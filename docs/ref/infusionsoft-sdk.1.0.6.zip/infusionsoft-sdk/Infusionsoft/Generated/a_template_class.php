<?php echo '<?php' . "\n"; ?>
class Infusionsoft_<?php echo $this->table; ?> extends Infusionsoft_Generated_<?php echo $this->table; ?>{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

