<?php
class Infusionsoft_LeadSourceCategory extends Infusionsoft_Generated_LeadSourceCategory {
    public function __construct($id = null, $app = null){
        parent::__construct($id, $app);
    }
}

