<?php
class Infusionsoft_LeadSourceExpense extends Infusionsoft_Generated_LeadSourceExpense {
    public function __construct($id = null, $app = null){
        parent::__construct($id, $app);
    }
}

