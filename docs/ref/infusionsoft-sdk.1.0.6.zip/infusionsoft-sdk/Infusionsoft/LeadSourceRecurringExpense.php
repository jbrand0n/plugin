<?php
class Infusionsoft_LeadSourceRecurringExpense extends Infusionsoft_Generated_LeadSourceRecurringExpense {
    public function __construct($id = null, $app = null){
        parent::__construct($id, $app);
    }
}

