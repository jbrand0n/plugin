<?php
class Infusionsoft_Product extends Infusionsoft_Generated_Product{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

