<?php
class Infusionsoft_Referral extends Infusionsoft_Generated_Referral{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

